import mongoose from "mongoose";

const PostSchema = mongoose.Schema({
  title: {
    type: "string",
    required: true,
    unique: true,
  },
  description: {
    type: "string",
    required: true,
  },
  picture: {
    type: "string",
    required: false,
  },
  username: {
    type: "string",
    required: true,
  },
  categories: {
    type: "string",
    required: false,
  },
  createdDate: {
    type: Date,
  },
});

const post = mongoose.model("Post", PostSchema);

export default post;
