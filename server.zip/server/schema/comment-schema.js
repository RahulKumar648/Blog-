import  mongoose from "mongoose";

const CommentSchema = mongoose.Schema({
    name:{
        type: 'string',
        required: true,
    },
    postId:{
        type: 'string',
        required: true,
    },
    date:{
        type: 'string',
        required: true,
    },
    comments:{
        type: 'string',
        required: true,
    },
})

const comment = mongoose.model('comment',CommentSchema);

export default comment; 